<?php
    header("location: Views/Home/login.php");
?>